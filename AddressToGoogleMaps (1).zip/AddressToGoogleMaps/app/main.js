// Initialize Zoho Embedded App SDK
ZOHO.embeddedApp.on("PageLoad", function(data) {
  // This gives the current record info when opened from record context
  console.log("PageLoad data:", data);
});

// Button click → fetch Lead address and open map
document.getElementById("openMap").addEventListener("click", async () => {
  try {
    const record = await ZOHO.CRM.API.getRecord({
      Entity: "Leads",
      RecordID: (await ZOHO.CRM.UI.Record.getRecordId()).data
    });

    console.log("Lead Record:", record);

    const lead = record.data[0];
    const address = [
      lead.Street,
      lead.City,
      lead.State,
      lead.Zip_Code,
      lead.Country
    ].filter(Boolean).join(", ");

    if (!address) {
      alert("No address found for this Lead.");
      return;
    }

    const mapUrl = `https://www.google.com/maps?q=${encodeURIComponent(address)}`;

    // Option A: open inside iframe
    document.getElementById("mapContainer").innerHTML = `<iframe src="${mapUrl}"></iframe>`;

    // Option B: open new tab → window.open(mapUrl, "_blank");

  } catch (err) {
    console.error("Error fetching lead:", err);
    alert("Could not fetch lead address.");
  }
});

ZOHO.embeddedApp.init();